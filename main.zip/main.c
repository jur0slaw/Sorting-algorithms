#include <stdio.h>
#include <stdlib.h>


void zapelnianie(int *m, int size, int zakres){
     srand(time (0));
     int i;
     for(i=0;i<size;i++){
        m[i]=rand()%zakres;
     }
}

void zamiana(int *p, int i, int j){
int c;
c=*(p+i);
*(p+i)=*(p+j);
*(p+j)=c;
}

int szukaj(int *p, int size, int k){
    int i;
    int min=p[k];
    int adres=k;
    for(i=k+1;i<size;i++){
        if(p[i]<=min){
            min=p[i];
            adres=i;
        }
    }
    return adres;
}

void insertowe(int *m, int size, int z){
   int i;
   for(i=0;i<size-1;i++){
        zamiana(m, szukaj(m,size,i),i);
        pokaz(m,size,z);
            system("cls");
   }
}


void pokaz(int *m, int size, int zakres){
    int i,j;
    for(i=0;i<zakres;i++){
        printf("%3i |", zakres-i);
        for(j=0;j<size;j++){
            if(m[j]==i){
                printf("*");
            }else{
                printf(" ");
            }
        }
        printf("\n");
    }
    printf("   ");
    for(j=0;j<size;j++){
            printf("_");
        }
}

/*void sortowanie(int *m, int size,int z){
    int licznik=0;
    int i;
    while(licznik<size-1){
            licznik=0;
        for(i=0;i<size-1;i++){
            if(m[i]>m[i+1]){
                zamiana(m,i);
            }else{
                licznik++;
            }
            pokaz(m,size,z);
            system("cls");
        }

    }
}
*/


void wypisywanie(int *m, int size){
    int i;
    for(i=0;i<size;i++){
        printf("%i \n",m[i]);
    }
}

int main()
{
    int k;
    printf("Wprowadz wielkosc tablicy ktora bedziemy sortowac: ");
    scanf("%i", &k);
    if(k<0){
        k=abs(k);
    }
    if(k==0){
        return 0;
    }
    int matrix[k];
    printf("\n Wprowadz zakres wartosci ktore bedziemy sortowa�: ");
    int j;
    scanf("%i",&j);
    if(j<0){
        j=abs(j);
    }
    if(j==0){
        return 0;
    }
    zapelnianie(matrix,k,j);
    printf("Twoja tablica wyglada tak: \n");
    wypisywanie(matrix, k);
    printf("Teraz ja posortujemy: \n");
    //sortowanie(matrix,k,j);
    insertowe(matrix,k,j);
    printf("Twoja tablica wyglada tak: \n");
    wypisywanie(matrix, k);

    return 0;
}
